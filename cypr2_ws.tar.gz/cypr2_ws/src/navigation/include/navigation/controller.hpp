#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"

class Controller : public rclcpp::Node
{
public:
    Controller();

    void publish_method();

    ~Controller();

    private:

    rclcpp::Publisher<std_msgs::msg::String>::SharedPtr publisher_;

    size_t count_;
};
