#include "rclcpp/rclcpp.hpp"
#include "std_msgs/msg/string.hpp"
#include "geometry_msgs/msg/Twist"
#include <string>

class Actuator : public rclcpp::Node
{
public:
    Actuator();

    void execute_command(const std_msgs::msg::String::SharedPtr msg) const;

private:
    rclcpp::Publisher<geometry_msgs::msg::Twist>::SharedPtr pub_;
    rclcpp::Subscription<std_msgs::msg::String>::SharedPtr sub_;

    size_t count_;
};

