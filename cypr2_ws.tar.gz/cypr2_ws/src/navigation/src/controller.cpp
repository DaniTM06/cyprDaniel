#include <navigation/controller.hpp>

Controller::Controller(): Node ( "Controller" )
{
    publisher_ =  this->create_publisher<std_msgs::msg::String> ( "command", 10);
    count_=0;
}

Controller::~Controller()
{
    printf("Leaving\n");
}

void Controller::publish_method()
{
auto message = std_msgs::msg::String();
int random= round(4*(float)rand()/(float)RAND_MAX);
count_++;
        switch (random){
        case 0:message.data = "stop"; break;
        case 1:message.data = "fordwards";break;
        case 2:message.data = "backwards";break;
        case 3:message.data = "left";break;
        case 4:message.data = "right";break;
 }
    RCLCPP_INFO ( this->get_logger(), "[#%ld] Publishing: '%s'",
                  count_, message.data.c_str() );

    publisher_ ->publish ( message );
}

 int main (int argc, char * argv[] )

    {
        rclcpp::init ( argc, argv);

        Controller p;

        rclcpp::Rate loop_rate(10);

        while (rclcpp::ok())
        {
            p.publish_method();
            loop_rate.sleep();
        }
        rclcpp::shutdown();
        return 0;
    }

